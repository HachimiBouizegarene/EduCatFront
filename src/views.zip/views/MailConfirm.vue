<template>
  <NavBar></NavBar>
  <div class="container">
    <div class="left-part">
      <LogoDeco logo_url="login_page/logo_login.png"></LogoDeco>
    </div>
    <div id="titre">Mot de passe oublié</div>
    <div id="modification">
      <p>Mail de connexion :</p>

      <input
        v-model="email"
        type="email"
        id="mail"
        placeholder="Adresse mail"
        required
      />
    </div>
    <button id="btn_confirmer" @click="sendEmail" :disabled="sending">
      {{ sending ? "Envoi en cours..." : "Envoyer le mail" }}
    </button>
    <p v-if="errorMessage" style="color: red">{{ errorMessage }}</p>
  </div>
  <FooterComp></FooterComp>
</template>

<script>
import NavBar from "@/components/all/NavBar.vue";
import LogoDeco from "@/components/log_sign/logoDeco.vue";
import FooterComp from "@/components/all/FooterComp.vue";
export default {
  components: {
    NavBar,
    LogoDeco,
    FooterComp,
  },
  data() {
    return {
      email: "", // initialiser l'e-mail à vide
      sending: false,
      errorMessage: "",
    };
  },
  methods: {
    async sendEmail() {
      this.sending = true;
      try {
        const response = await fetch("http://localhost:9090/mail-confirm", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            email: this.email,
          }),
        });
        if (!response.ok) {
          throw new Error(
            `Erreur lors de l'envoi de l'e-mail : ${response.statusText}`
          );
        }
        const data = await response.text();
        console.log(data);
        this.errorMessage = "";
      } catch (error) {
        console.error("Erreur lors de l'envoi de l'e-mail:", error);
        this.errorMessage =
          "Une erreur s'est produite lors de l'envoi de l'e-mail.";
      } finally {
        this.sending = false;
      }
    },
  },
};
</script>

<style scoped>
.container {
  background-color: rgb(255, 255, 255);
  display: flex;
  flex-direction: row;
  text-align: center;
  width: 96%;
  margin: auto;
  height: 700px;
  margin-top: 130px;
  margin-bottom: 70px;
  left: 0;
  overflow: hidden;
}
.container .left-part {
  overflow: hidden;
  width: 50%;
  height: 100%;
  background-color: #ffd1a5;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: space-around;
  position: relative;
}

#modification {
  width: 20%;
  margin: auto;
  display: flex;
  flex-direction: column;
  text-align: left;
  justify-content: center;
}

#modification p {
  padding: 10px 0;
}

#modification input {
  padding: 10px 0;
  margin-bottom: 30px;
  border: none;
  border-bottom: 3px rgb(90, 89, 89) solid;
  background: none;
  outline: none;
}

#modification input:focus,
#modification input:hover {
  border-color: black;
}
#btn_confirmer {
  width: 65%;
  color: rgb(53, 52, 52);
  background-color: #ffd1a5;
  padding: 17px 10px;
  border: none;
  cursor: pointer;
  transition: 0.15s ease;
  margin-top: 5%;
  display: flex;
  justify-content: center;
  margin-right: auto;
  margin-left: auto;
}

#btn_confirmer.activated {
  background-color: #ffa450;
  pointer-events: all;
}

#btn_confirmer.activated:hover {
  background-color: #ffb167;
}
</style>
