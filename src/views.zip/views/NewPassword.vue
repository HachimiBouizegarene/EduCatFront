<template>
  <div id="main">
    <form @submit.prevent="verifyInputs">
      <h1 id="title">Changement du mot de passe</h1>

      <input v-model="password" placeholder="Mot de passe" type="password" />

      <input
        v-model="password_conf"
        placeholder="Confirmer mot de passe"
        type="password"
      />

      <button :class="{ activated: verifyInputs() }" type="submit">
        ENREGISTRER
      </button>
    </form>
  </div>
</template>

<script>
export default {
  data() {
    return {
      password: "",
      password_conf: "",
    };
  },
  methods: {
    verifyInputs() {
      return this.password !== "" && this.password_conf === this.password;
    },
    async changePassword() {
      try {
        // Vérifier que les mots de passe sont identiques
        if (this.password !== this.password_conf) {
          throw new Error("Les mots de passe ne correspondent pas");
        }

        // Construire l'objet à envoyer au serveur
        const data = {
          jws: "Votre JWT ici", // Remplacez par votre JWT
          newPassword: this.password,
        };

        // Envoyer la requête POST au serveur
        const response = await fetch(
          "http://localhost:8080/updatePasswordForgot",
          {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify(data),
          }
        );

        // Vérifier la réponse du serveur
        if (!response.ok) {
          throw new Error("Échec de la demande au serveur");
        }

        // Récupérer la réponse du serveur
        const responseData = await response.json();

        // Vérifier si la demande a réussi ou non
        if (responseData.error) {
          throw new Error(responseData.error);
        }

        // Afficher un message de succès
        alert(responseData.success);
      } catch (error) {
        // Afficher les erreurs
        alert("Erreur lors du changement de mot de passe : " + error.message);
      }
    },
  },
};
</script>

<style scoped>
#main {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  height: 100vh;
  background-color: #f5f5f5;
}

#main h1 {
  color: rgb(53, 52, 52);
}

#main form {
  width: 30%;
  margin: auto;
  display: flex;
  flex-direction: column;
  text-align: left;
  justify-content: center;
}

#title {
  padding: 30px 0;
}

input {
  padding: 10px 0;
  margin-bottom: 30px;
}
</style>
