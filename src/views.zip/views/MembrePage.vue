<template>
  <h1>goat</h1>
</template>

<script>
export default {
    name: "MembrePage"
}
</script>

<style>

</style>