
<template>
    <NavBar></NavBar>
    <div id="Container">
        <p style="background: transparent;line-height: 130%;margin-bottom: 0in;text-align: center;"><span
                style="color: #313131; font-size: 30px;">Mentions l&eacute;gales</span></p>
        <p style="background: transparent;line-height: 130%;margin-bottom: 0in;text-align: center;"><span
                style="">&nbsp;</span></p>
        <p style="background: transparent;line-height: 130%;margin-bottom: 0in;text-align: left;"><span
                style="">Conform&eacute;ment aux dispositions des Articles 6-III et 19 de la Loi
                n&deg;2004-575 du 21 juin 2004 pour la Confiance dans l&rsquo;&eacute;conomie num&eacute;rique, dite
                L.C.E.N.,
                il est port&eacute; &agrave; la connaissance des utilisateurs et visiteurs, ci-apr&egrave;s
                l&quot;&quot;Utilisateur&quot;, du site http://localhost , ci-apr&egrave;s le
                &quot;Site&quot;, les pr&eacute;sentes mentions l&eacute;gales.</span></p>
        <p style="background: transparent;line-height: 130%;margin-bottom: 0in;text-align: left;"><br></p>
        <p style="background: transparent;line-height: 130%;margin-bottom: 0in;text-align: left;"><span style="">La
                connexion et la navigation sur le Site par l&rsquo;Utilisateur implique
                acceptation int&eacute;grale et sans r&eacute;serve des pr&eacute;sentes mentions l&eacute;gales.</span></p>
        <p style="background: transparent;line-height: 130%;margin-bottom: 0in;text-align: left;"><br></p>
        <p style="background: transparent;line-height: 130%;margin-bottom: 0in;text-align: left;"><span style="">Ces
                derni&egrave;res sont accessibles sur le Site &agrave; la rubrique &laquo;
                Mentions l&eacute;gales &raquo;.</span></p>
        <p style="background: transparent;line-height: 130%;margin-bottom: 0in;text-align: left;"><br></p>
        <p style="background: transparent;line-height: 130%;margin-bottom: 0in;text-align: left;"><span
                style="color: #313131;"><u>ARTICLE 1 - L&apos;EDITEUR</u></span></p>
        <p style="background: transparent;line-height: 130%;margin-bottom: 0in;text-align: left;"><br></p>
        <p style="background: transparent;line-height: 130%;margin-bottom: 0in;text-align: left;"><span
                style="">L&apos;&eacute;dition du Site est assur&eacute;e par Educat SARL au capital de 1
                euros, immatricul&eacute;e au Registre du Commerce et des Soci&eacute;t&eacute;s de Paris sous le
                num&eacute;ro
                123456789 dont le si&egrave;ge social est situ&eacute; au 66 rue des martyrs paris,&nbsp;</span></p>
        <p style="background: transparent;line-height: 130%;margin-bottom: 0in;text-align: left;"><span
                style="">Num&eacute;ro de t&eacute;l&eacute;phone 0607080910,&nbsp;</span></p>
        <p style="background: transparent;line-height: 130%;margin-bottom: 0in;text-align: left;"><span style="">Adresse
                e-mail : educat@gmail.com.</span></p>
        <p style="background: transparent;line-height: 130%;margin-bottom: 0in;text-align: left;"><span style="">N&deg; de
                TVA intracommunautaire : FR 40 123456890</span></p>
        <p style="background: transparent;line-height: 130%;margin-bottom: 0in;text-align: left;"><span style="">Le
                Directeur de la publication est MINOT Quentin</span></p>
        <p style="background: transparent;line-height: 130%;margin-bottom: 0in;text-align: left;"><span
                style="">ci-apr&egrave;s l&apos;&quot;Editeur&quot;.</span></p>
        <p style="background: transparent;line-height: 130%;margin-bottom: 0in;text-align: left;"><br></p>
        <p style="background: transparent;line-height: 130%;margin-bottom: 0in;text-align: left;"><span
                style="color: #313131;"><u>ARTICLE 2 - L&apos;HEBERGEUR</u></span></p>
        <p style="background: transparent;line-height: 130%;margin-bottom: 0in;text-align: left;"><br></p>
        <p style="background: transparent;line-height: 130%;margin-bottom: 0in;text-align: left;"><span
                style="">L&apos;h&eacute;bergeur du Site est la soci&eacute;t&eacute; Hostinger, dont le
                si&egrave;ge social est situ&eacute; au HOSTINGER INTERNATIONAL LTD, 61 Lordou Vironos Street, 6023 Larnaca,
                Chypre , avec le num&eacute;ro de t&eacute;l&eacute;phone :&nbsp;<span lang="fr-FR">01
                    49 45 49 20&nbsp;</span>+&nbsp;press@hostinger.com</span></p>
        <p style="background: transparent;line-height: 130%;margin-bottom: 0in;text-align: left;"><br></p>
        <p style="background: transparent;line-height: 130%;margin-bottom: 0in;text-align: left;"><span
                style="color: #313131;"><u>ARTICLE 3 - ACCES AU SITE</u></span></p>
        <p style="background: transparent;line-height: 130%;margin-bottom: 0in;text-align: left;"><br></p>
        <p style="background: transparent;line-height: 130%;margin-bottom: 0in;text-align: left;"><span style="">Le Site est
                accessible en tout endroit, 7j/7, 24h/24 sauf cas de force majeure,
                interruption programm&eacute;e ou non et pouvant d&eacute;coulant d&rsquo;une n&eacute;cessit&eacute; de
                maintenance.</span></p>
        <p style="background: transparent;line-height: 130%;margin-bottom: 0in;text-align: left;"><br></p>
        <p style="background: transparent;line-height: 130%;margin-bottom: 0in;text-align: left;"><span style="">En cas de
                modification, interruption ou suspension du Site, l&apos;Editeur ne
                saurait &ecirc;tre tenu responsable.</span></p>
        <p style="background: transparent;line-height: 130%;margin-bottom: 0in;text-align: left;"><br></p>
        <p style="background: transparent;line-height: 130%;margin-bottom: 0in;text-align: left;"><span
                style="color: #313131;"><u>ARTICLE 4 - COLLECTE DES DONNEES</u></span></p>
        <p style="background: transparent;line-height: 130%;margin-bottom: 0in;text-align: left;"><br></p>
        <p style="background: transparent;line-height: 130%;margin-bottom: 0in;text-align: left;"><span style="">Le Site
                assure &agrave; l&apos;Utilisateur une collecte et un traitement
                d&apos;informations personnelles dans le respect de la vie priv&eacute;e conform&eacute;ment &agrave; la loi
                n&deg;78-17 du 6 janvier 1978 relative &agrave; l&apos;informatique, aux fichiers et aux
                libert&eacute;s.&nbsp;</span></p>
        <p style="background: transparent;line-height: 130%;margin-bottom: 0in;text-align: left;"><br></p>
        <p style="background: transparent;line-height: 130%;margin-bottom: 0in;text-align: left;"><span style="">En vertu de
                la loi Informatique et Libert&eacute;s, en date du 6 janvier 1978,
                l&apos;Utilisateur dispose d&apos;un droit d&apos;acc&egrave;s, de rectification, de suppression et
                d&apos;opposition de ses donn&eacute;es personnelles. L&apos;Utilisateur exerce ce droit :</span></p>
        <p style="background: transparent;line-height: 130%;margin-bottom: 0in;text-align: left;"><span style="">&middot;
                via un formulaire de contact ;</span></p>
        <p style="background: transparent;line-height: 130%;margin-bottom: 0in;text-align: left;"><span
                style="">&nbsp;</span></p>
        <p style="background: transparent;line-height: 130%;margin-bottom: 0in;text-align: left;"><span style="">&middot;
                via son espace personnel ;</span></p>
        <p style="background: transparent;line-height: 130%;margin-bottom: 0in;text-align: left;"><span
                style="">&nbsp;</span></p>
        <p style="background: transparent;line-height: 130%;margin-bottom: 0in;text-align: left;"><span style="">Toute
                utilisation, reproduction, diffusion, commercialisation, modification de
                toute ou partie du Site<span lang="hi-IN"></span>, sans autorisation de l&rsquo;Editeur est prohib&eacute;e
                et
                pourra entra&icirc;n&eacute;e des actions et poursuites judiciaires telles que notamment pr&eacute;vues par
                le
                Code de la propri&eacute;t&eacute; intellectuelle et le Code civil.</span></p>
        <p style="background: transparent;line-height: 130%;margin-bottom: 0in;text-align: left;"><br></p>
        <p style="background: transparent;line-height: 130%;margin-bottom: 0in;text-align: left;"><span style="">Pour plus
                d&apos;informations en mati&egrave;re de protection des donn&eacute;es
                &agrave; caract&egrave;re personnel , se reporter &agrave; la Charte en mati&egrave;re de protection des
                donn&eacute;es &agrave; caract&egrave;re personnel du site http://localhost accessible &agrave; la rubrique
                &quot;Donn&eacute;es personnelles&quot;</span></p>
        <p style="background: transparent;line-height: 130%;margin-bottom: 0in;text-align: left;"><span style="">Pour plus
                d&apos;informations en mati&egrave;re de cookies, se reporter &agrave; la
                Charte en mati&egrave;re de cookies du site http://localhost accessible &agrave; la rubrique
                &quot;Cookies&quot;</span></p>
        <p style="background: transparent;line-height: 130%;margin-bottom: 0in;text-align: left;"><br></p>

        
    </div>
    <FooterComp></FooterComp>
</template>

<style scoped>
#Container {
    margin: 100px auto;
    width: 50vw;
    max-width: 785px;
    background-color: #ececec;
    padding: 33px;
    color: black;
}
</style>


<script>
import NavBar from "@/components/all/NavBar.vue"
import FooterComp from "@/components/all/FooterComp.vue";

export default {
    name: "MentionsLegales",

    components: {
        NavBar,
        FooterComp
    },


    data() {
        return {
        };
    },

    methods: {
    }
}
</script>